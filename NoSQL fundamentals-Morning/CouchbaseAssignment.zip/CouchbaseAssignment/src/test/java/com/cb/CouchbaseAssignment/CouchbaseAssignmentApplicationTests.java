package com.cb.CouchbaseAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouchbaseAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
