package com.cb.CouchbaseAssignment;



import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;

@Configuration
public class Config extends AbstractCouchbaseConfiguration{

	@Override
	public String getConnectionString() {
		// TODO Auto-generated method stub
		return "127.0.0.1";
	}

	@Override
	public String getUserName() {
		// TODO Auto-generated method stub
		return "admin";
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return "admin1";
	}

	@Override
	public String getBucketName() {
		// TODO Auto-generated method stub
		return "Employee";
	}

}
