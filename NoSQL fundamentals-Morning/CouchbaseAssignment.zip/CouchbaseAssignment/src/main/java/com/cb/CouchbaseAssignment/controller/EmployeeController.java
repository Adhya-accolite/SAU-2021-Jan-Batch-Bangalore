package com.cb.CouchbaseAssignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import com.cb.CouchbaseAssignment.model.Employee;
import com.cb.CouchbaseAssignment.repo.EmployeeRepo;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	
	
	public String storeEmployee(@RequestBody Employee employee)
	{
		employeeRepo.save(employee);
		return "Employee data stored successfully";
	}
	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<Employee> totalEmployee(){
		return employeeRepo.findAll();
	}
}
