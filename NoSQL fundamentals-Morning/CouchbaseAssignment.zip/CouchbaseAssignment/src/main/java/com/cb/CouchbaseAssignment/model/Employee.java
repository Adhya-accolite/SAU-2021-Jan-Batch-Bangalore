package com.cb.CouchbaseAssignment.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;

@Document
public class Employee {
	
	@Id
	private String id;
	private String name;
	private String pincode;
	
	public Employee(String id, String name, String pincode) {
		this.id = id;
		this.name =name;
		this.pincode = pincode;
	}

	public String getEmpId() {
		return id;
	}

	public void setEmpId(String id) {
		this.id = id;
	}

	public String getEmpName() {
		return name;
	}

	public void setEmpName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return pincode;
	}

	public void setAddress(String pincode) {
		this.pincode = pincode;
	}
}
	
	